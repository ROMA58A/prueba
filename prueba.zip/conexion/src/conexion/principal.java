
package conexion;


public class principal {

    
    public static void main(String[] args) 
    {
        prueba objetoprueba= new prueba();
         objetoprueba.setVisible(true);
         
  
         
    }

   
}
