
package conexion;
 import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.JOptionPane;


public class conexxion {     
  
          
    
  public Connection estableceConexion() {
  
      Connection conectar = null;

    try {
        // Cargar el controlador de MySQL
        Class.forName("com.mysql.jdbc.Driver");

        // Establecer la conexión con la base de datos MySQL 
        // despues de establecerla paraa probarla cambiar la base de datos 
        conectar = DriverManager.getConnection("jdbc:mysql://localhost:3306/conex", "root", "");
     
    } catch (Exception e) {
        System.out.println("Mensaje de error: " + e.getMessage());
        JOptionPane.showMessageDialog(null, "No se pudo conectar"+e.toString());
    }

    return conectar;
}


}

  